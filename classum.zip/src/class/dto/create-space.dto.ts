export class CreateSpaceDto{
    name : string;
    logo : string;
}