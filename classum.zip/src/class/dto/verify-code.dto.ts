

export class VerifyCodeDto{
    verifyCode : string;
}