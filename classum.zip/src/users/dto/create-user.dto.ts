export class CreateUserDto {
    email:string;
    password:string;
    firstname:string;
    lastname:string;
    profile_img_url:string;
    refreshToken : string;
}
