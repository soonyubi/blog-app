export class CreateSpaceRoleDto{
    admin : string[];
    participant : string[];
}